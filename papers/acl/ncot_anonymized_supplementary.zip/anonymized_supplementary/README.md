# Narrative Chain-of-Thought (N-CoT): Anonymous Reproducibility Kit

Supplementary code and aggregated data for the ARR submission
*Narrative Chain-of-Thought: Inference-Time Scaffolding for Defeasible
Ethical Reasoning in Large Language Models*.

This archive is fully anonymised. All vendor accounts, internal paths,
and author identifiers have been redacted. The artefacts here are
sufficient to (a) re-derive every figure and table in the paper from the
shipped CSVs and (b) re-run the full generation, judging, and analysis
pipeline against any compatible model endpoint.

## Layout

```
.
|-- README.md                          (this file)
|-- requirements.txt                   pinned-or-lower Python dependencies
|-- .env.template                      environment-variable template (no secrets)
|-- ncot_divergence_pilot.ipynb        original analysis notebook
|-- run_debate_std_cot_ablation.py     standalone debate ablation driver
|-- run_phase_c.py                     standalone Phase-C harness
|-- scripts/                           experimental + analysis pipeline (22 modules)
|-- data/
|   `-- adversarial_sycophancy_probes.json   stimuli for Appendix D probe
|-- Guidance_Documents/
|   |-- study_design.md                full pre-registration and execution log
|   `-- tier3_preregistration.md       deferred Tier-3 human-eval design
`-- divergence_study_outputs/          90 aggregated CSVs + summary JSON
                                       (no per-call API cache; see below)
```

The aggregated CSVs in `divergence_study_outputs/` underlie every
quantitative claim in the manuscript. Per-call API result caches (~150k
JSON files, ~750 MB) are intentionally excluded because they are
deterministically reproduced by the scripts under fixed seeds and cache
keys, and would not survive review-time anonymity constraints. Cache
files regenerate on first run of any script that needs them.

## Models used

The paper uses four generators from three vendors and two judges. The
following identifiers are referenced by configuration; supply any
compatible endpoint at runtime.

| Role             | Model identifier (paper)         |
|------------------|----------------------------------|
| Generator A      | `gpt-5.4-nano`                   |
| Generator B      | `gpt-4o`                         |
| Generator C      | `claude-haiku-4-5`               |
| Generator D      | `claude-sonnet-4-6`              |
| Generator E      | `grok-4-1-fast-reasoning`        |
| Primary judge    | `gpt-4o-mini`                    |
| Secondary judge  | `claude-sonnet-4-6`              |
| Held-out judge   | `grok-4-1-fast-reasoning`        |

## Setup

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.template .env
# Populate .env with your endpoint URLs and API keys before running.
```

## Reproducing every result from the shipped CSVs (no API calls)

All figure and table values in the paper come from
`divergence_study_outputs/*.csv`. Key entry points:

| Paper element                                        | CSV (under `divergence_study_outputs/`)             |
|------------------------------------------------------|-----------------------------------------------------|
| Table 1 / Figure 3 (Experiment 1 quartet)            | `failure_mode_firing_quartet.csv`, `tier1_effect_sizes_quartet.csv`, `phase1_quartet_raw.csv` |
| Table 2 (length residualisation)                     | `length_residualized_effects.csv`                   |
| Figure 4 (sub-instruction ablation)                  | `subinstruction_attribution.csv`, `phase2_ablation_raw.csv` |
| Figure 5 / Section 5 (debate convergence)            | `debate_full_arc.csv`, `debate_consensus.csv`, `debate_v4_final.csv`, `debate_v4_integrated_proposals.csv` |
| Section 5 replication (DailyDilemmas 30 scenarios)   | `scaled_decisions.csv`, `scaled_tier1_effect_sizes.csv`, `scaled_mp_ncot_judge.csv` |
| Cross-vendor moderator robustness (Appendix A)       | `debate_cross_vendor_moderator_sonnet.csv`, `interjudge_agreement.csv`, `per_scenario_kappa.csv` |
| K_C panel (Appendix C: graph + length-invariant)     | `kc_graph_scaled.csv`, `kc_graph_scaled_corr.csv`, `kc_proxy_panel.csv`, `kc_proxy_panel_residualized.csv`, `phase1_kc_scores.csv` |
| Refusal benchmarks (Appendix D, E5)                  | `refusal_e5_xstest.csv` (plus per-cell raw JSON in cache when regenerated) |
| Agentic probe set (Appendix D)                       | `agentic_probe_results.csv`                         |
| SycophancyEval probe (Appendix D)                    | `adversarial_sycophancy_raw.csv`                    |

To regenerate all paper figures from these CSVs without any API calls:

```bash
python scripts/rebuild_paper_figures.py
```

## Re-running the experiments end-to-end

The pipeline is organised as numbered phases. Each script is idempotent:
re-running uses the on-disk cache and only issues API calls for the
missing cells.

```bash
# Experiment 1: N-CoT at scale, four generators, DailyDilemmas (100 scenarios)
python scripts/run_phase1_quartet.py

# Verbose-CoT matched-budget control (E1 variant)
python scripts/calibrate_ncot_budgets.py   # produces ncot_median_budgets.json
python scripts/run_phase1_quartet.py --condition standard_cot_verbose

# Sub-instruction ablation on claude-sonnet-4-6
python scripts/run_phase2_ablation.py

# Held-out judge (grok) sanity check
python scripts/run_heldout_judge_grok.py

# Cross-vendor moderator robustness
python scripts/run_cross_vendor_moderator.py

# Experiment 2: five-round multi-stakeholder debate (calibration set)
python scripts/run_phase3_debate.py

# Experiment 2: DailyDilemmas replication (30 scenarios)
python scripts/run_phase5_e2_scaled.py

# K_C: graph proxy at scale + convergent proxy panel (E6/E7)
python scripts/run_phase8_kc_scaled.py

# Refusal modulation: XSTest + SimpleSafetyTests (E5)
python scripts/run_phase6_refusal.py

# Deployment-relevance probes (Appendix D)
python scripts/run_agentic_probe.py
python scripts/run_sycophancyeval.py

# Aggregate everything
python scripts/aggregate_e1_to_e4.py
python scripts/aggregate_phase1.py
```

## Anonymity notice

Author and account identifiers have been removed throughout the
archive. The .env template references generic endpoint variables; do
not commit your filled-in `.env`. If you find any residual identifying
information, please flag it to the area chair.

Note: a handful of CSV rows under `divergence_study_outputs/` contain
model-generated character names from the pharma-whistleblower
calibration scenario (for example "Dr. Kirkpatrick", "Priya", "Elena").
These are entirely fictional names produced by the generators during
the debate experiment and are preserved verbatim to avoid altering
recorded experimental data.

## Licence

Code is released under the MIT licence for the purposes of review.
External datasets (DailyDilemmas, XSTest, SimpleSafetyTests) remain
under their original licences and must be obtained from their original
distributors; we do not redistribute them here.
